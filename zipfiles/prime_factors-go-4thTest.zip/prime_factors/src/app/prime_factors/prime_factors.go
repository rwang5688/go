// prime_factors project prime_factors.go
package prime_factors

type PrimeFactors struct {
}

// initialize struct variables
func (p *PrimeFactors) Init() {
}

// generate prime factors
func (p *PrimeFactors) Generate(num int) []int {
	result := []int{}

	// extract all factors of 2
	n := num
	for n%2 == 0 {
		result = append(result, 2)
		n /= 2
	}

	// whatever remains must be a prime factor (faulty logic!)
	if n > 1 {
		result = append(result, n)
	}

	return result
}
