// bowling_game project game.go
package bowling_game

type Game struct {
	score_ int
}

// initialize struct variables
func (g *Game) Init() {
	g.score_ = 0
}

// keep track of rolls
func (g *Game) Roll(pins int) {
	g.score_ += pins
}

// calculate score
func (g Game) Score() int {
	return g.score_
}

// game rule helper functions
