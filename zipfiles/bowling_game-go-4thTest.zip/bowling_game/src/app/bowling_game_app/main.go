// bowling_game_app project main.go
package main

import (
	"app/bowling_game"
	"fmt"
)

func main() {
	fmt.Println("bowling_game_app.exe")

	// replicate logic of the final test
	g := &bowling_game.Game{}
	g.Roll(10) // strike
	g.Roll(1)
	g.Roll(1) // strike bonus = 2
	for i := 0; i < 16; i++ {
		g.Roll(0)
	}
	fmt.Println(g.Score())
}
