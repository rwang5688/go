// prime_factors project prime_factors.go
package prime_factors

type PrimeFactors struct {
}

// initialize struct variables
func (p *PrimeFactors) Init() {
}

// generate prime factors
func (p *PrimeFactors) Generate(num int) []int {
	result := []int{}

	if num > 1 {
		result = append(result, 2)
	}

	return result
}
