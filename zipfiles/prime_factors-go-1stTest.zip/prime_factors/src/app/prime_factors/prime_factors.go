// prime_factors project prime_factors.go
package prime_factors

type PrimeFactors struct {
}

// initialize struct variables
func (p *PrimeFactors) Init() {
}

// generate prime factors
func (p *PrimeFactors) Generate(num int) []int {
	result := []int{}
	return result
}
