// package must be "main" to install $(directory_name).exe to $(GOPATH)/bin
package main

import (
	"app/bowling_game"
	"fmt"
)

func main() {
	fmt.Println("bowling_game_app.exe")
	g := &bowling_game.Game{}
	g.Roll(5)
	g.Roll(5) // spare
	g.Roll(3) // spare bonus
	for i := 0; i < 17; i++ {
		g.Roll(0)
	}
	fmt.Println(g.Score())
}
