package bowling_game

type Game struct {
	score_ int
}

func (g *Game) Init() {
	g.score_ = 0
}

func (g *Game) Roll(pins int) {
	g.score_ += pins
}

func (g Game) Score() int {
	return g.score_
}
