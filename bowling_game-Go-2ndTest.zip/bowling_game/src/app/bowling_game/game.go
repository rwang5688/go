package bowling_game

type Game struct {
}

func (g *Game) Roll(pins int) {
}

func (g Game) Score() int {
	return 0
}
