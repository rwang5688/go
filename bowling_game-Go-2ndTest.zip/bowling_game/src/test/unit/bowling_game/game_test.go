package bowling_game_unittest

import (
	"app/bowling_game"
	"strconv"
	"testing"
)

// Setup
func setUp() *bowling_game.Game {
	g := &bowling_game.Game{}
	return g
}

// 1st Test
func TestGutterGame(t *testing.T) {
	// Arrange
	g := setUp()

	// Act
	for i := 0; i < 20; i++ {
		g.Roll(0)
	}

	// Assert
	s := g.Score()
	if s != 0 {
		t.Error(`Expected score is 0; score is ` + strconv.Itoa(s))
	}
}

// 2nd Test
func TestAllOnes(t *testing.T) {
	// Arrange
	g := setUp()

	// Act
	for i := 0; i < 20; i++ {
		g.Roll(1)
	}

	// Assert
	s := g.Score()
	if s != 20 {
		t.Error(`Expected score is 20; score is ` + strconv.Itoa(s))
	}
}
