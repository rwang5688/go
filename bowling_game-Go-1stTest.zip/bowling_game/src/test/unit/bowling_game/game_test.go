package bowling_game_unittest

import (
	"app/bowling_game"
	"strconv"
	"testing"
)

// Setup
func setUp() *bowling_game.Game {
	return &bowling_game.Game{}
}

// 1st Test
func TestGutterGame(t *testing.T) {
	// Arrange
	g := setUp()

	// Act

	// Assert
	s := g.Score()
	if s != 0 {
		t.Error(`Expected score is 0; score is ` + strconv.Itoa(s))
	}
}
