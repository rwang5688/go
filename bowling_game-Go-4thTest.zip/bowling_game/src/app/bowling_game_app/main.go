// package must be "main" to install $(directory_name).exe to $(GOPATH)/bin
package main

import (
	"app/bowling_game"
	"fmt"
)

func main() {
	fmt.Println("bowling_game_app.exe")
	g := &bowling_game.Game{}
	g.Roll(10) // strike
	g.Roll(3) // strike bonus
	g.Roll(4) // strike bonus
	for i := 0; i < 16; i++ {
		g.Roll(0)
	}
	fmt.Println(g.Score())
}
